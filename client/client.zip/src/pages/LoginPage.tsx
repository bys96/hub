import React from "react";

const LoginPage: React.FC = () => {
  return (
    <div className="min-h-screen flex justify-center items-center">
      <h1>로그인 페이지</h1>
      {/* 로그인 폼 컴포넌트 */}
    </div>
  );
};

export default LoginPage;
