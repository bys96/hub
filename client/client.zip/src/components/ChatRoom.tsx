import React, { useState, useEffect, useRef } from "react";
import RoomInfo from "./RoomInfo";

const ChatRoom: React.FC = () => {
  const [messages, setMessages] = useState([
    {
      id: 1,
      user: "기획자",
      job: "기획자",
      color: "text-blue-500",
      message: "집에 가고싶은...",
      time: "2분 전",
    },
    {
      id: 2,
      user: "택시기사",
      job: "택시기사",
      color: "text-yellow-500",
      message: "충암 같은 택시...",
      time: "5분 전",
    },
    // 더미 데이터 추가
  ]);
  const [newMessage, setNewMessage] = useState("");

  // 메시지 끝부분을 참조하기 위한 useRef
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const handleSendMessage = () => {
    if (newMessage.trim() === "") return;

    const newId = messages.length + 1;
    const newMsg = {
      id: newId,
      user: "기획자",
      job: "기획자",
      color: "text-blue-500",
      message: newMessage,
      time: "방금",
    };
    setMessages([...messages, newMsg]);
    setNewMessage("");
  };

  // 메시지가 추가될 때마다 스크롤을 아래로 이동시키는 useEffect
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  return (
    <div className="flex flex-col h-screen bg-gray-100 p-4">
      {/* 채팅방 전체 화면 */}
      <div className="flex-1 overflow-y-auto">
        {messages.map((msg) => (
          <div key={msg.id} className="flex items-start mb-4">
            <div className="w-10 h-10 bg-gray-300 rounded-full mr-4"></div>
            <div className="flex flex-col">
              <div className="flex items-center">
                <span className={`font-bold text-lg ${msg.color} mr-2`}>
                  {msg.user}
                </span>
                <span className="text-sm text-gray-500">{msg.job}</span>
              </div>
              <p className="text-gray-700">{msg.message}</p>
              <span className="text-sm text-gray-500">{msg.time}</span>
            </div>
          </div>
        ))}
        {/* 스크롤이 따라가도록 하기 위한 더미 div */}
        <div ref={messagesEndRef} />
      </div>

      {/* 채팅 입력 창 */}
      <div className="flex items-center border-t p-4 bg-white">
        <div className="w-10 h-10 bg-gray-300 rounded-full mr-4"></div>
        <input
          type="text"
          placeholder="내용을 입력해주세요."
          className="flex-1 border border-gray-300 rounded-lg p-2 text-gray-700"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
        />
        <button
          onClick={handleSendMessage}
          className="ml-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none"
        >
          전송
        </button>
      </div>

      {/* 방 정보 섹션 */}
      <RoomInfo
        title="주제"
        creator={{ name: "기획자", job: "기획자" }}
        participants={6}
        maxParticipants={6}
        openTime="2024-08-15 10:00"
        closeTime="2024-08-15 10:30"
        keywords={["#콜택시", "#반차"]}
      />
    </div>
  );
};

export default ChatRoom;
